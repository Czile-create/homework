#ifndef _START_H_
#define _START_H_
#include <bits/stdc++.h>
#include "readfile.h"
using namespace std;
void erase(haffman_tree *);
void _zip(int argc, char * argv[]);
void _unzip(string filename);
#endif